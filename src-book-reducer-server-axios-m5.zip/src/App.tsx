import React from 'react';
import logo from './logo.svg';
import './styles.css';
import 'bootstrap/dist/css/bootstrap.min.css'

//import Login from './components/login'
function App() {
  return (
    <div className="App">
     
    </div>
  );
}

export default App;
