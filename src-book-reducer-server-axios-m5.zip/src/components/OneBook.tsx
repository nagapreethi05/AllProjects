import react from 'react';
import { book } from './book';
import Star from './Star'
import { Navbar, Nav, Button, Form, Col, Card, FormControl } from 'react-bootstrap';

interface Iprops {
    book: book;
}
const OneBook = (props: Iprops) => {
    return (
        <>
            <Card  className="box h-199 w-12 shadow p-3 mb-5 bg-white rounded ">
                <Card.Img className="box-image" src={props.book.cover} title={props.book.title} />
                <Card.Body className="box-body ">
                    <Card.Text className="h-100 w-10" >
                        <h4 style={{"color":"black"}}><strong >Title:</strong>{props.book.title}</h4>
                        <h4><strong>Author:</strong>{props.book.author}</h4>
                        <Star value={props.book.rating}></Star>                    
                    </Card.Text></Card.Body>

            </Card>
           
        </>
    )
}
export default OneBook;