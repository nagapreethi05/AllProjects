import react from 'react';
import { book } from './book';
import Star from './Star'
import { Navbar, Nav, Button, Form, Col, Card, FormControl } from 'react-bootstrap';

interface Iprops {
    book: book;
}
const OneCard = (props: Iprops) => {
    return (
        <>
            <div className="container my-4">
                {/* <!--Carousel Wrapper--> */}
                <div id="multi-item-example" className="carousel slide carousel-multi-item" data-ride="carousel">

                    {/* <!--Controls--> */}
                    <div className="controls-top">
                        <a className="btn-floating" href="#multi-item-example" data-slide="prev"><i className="fas fa-chevron-left"></i></a>
                        <a className="btn-floating" href="#multi-item-example" data-slide="next"><i
                            className="fas fa-chevron-right"></i></a>
                    </div>
                    {/* <!--/.Controls--> */}

                    {/* <!--Indicators--> */}
                    <ol className="carousel-indicators">
                        <li data-target="#multi-item-example" data-slide-to="0" className="active"></li>
                        <li data-target="#multi-item-example" data-slide-to="1"></li>

                    </ol>
                    {/* <!--/.Indicators--> */}

                    {/* <!--Slides--> */}
                    {/* <div className="carousel-inner" role="listbox">
                        <Card className="box h-199 w-12 shadow p-3 mb-5 bg-white rounded ">
                            <Card.Img className="box-image" src={props.book.cover} title={props.book.title} />
                            <Card.Body className="box-body ">
                                <Card.Text className="h-100 w-10" >
                                    <h4 style={{ "color": "black" }}><strong >Title:</strong>{props.book.title}</h4>
                                    <h4><strong>Author:</strong>{props.book.author}</h4>
                                    <Star value={props.book.rating}></Star>
                                  
                                </Card.Text></Card.Body>

                        </Card>
                    </div>

                    {/* <!--First slide--> */}
                    <div className="carousel-item active">

                        <div className="col-md-3" >
                            <div className="card mb-2">
                                <img className="card-img-top"
                                    src={props.book.cover} title={props.book.title} />
                                <div className="card-body">
                                    <h4 style={{ "color": "black" }}><strong >Title:</strong>{props.book.title}</h4>
                                    <h4><strong>Author:</strong>{props.book.author}</h4>
                                    <Star value={props.book.rating}></Star>
                                    <a className="btn btn-primary">Button</a>
                                </div>
                            </div>
                        </div>
                        {/* <div className="col-md-3" style={{ "float": "left" }}>
                                <div className="card mb-2">
                                    <img className="card-img-top"
                                        src="https://mdbootstrap.com/img/Photos/Horizontal/City/4-col/img%20(60).jpg" alt="Card image cap" />
                                    <div className="card-body">
                                        <h4 className="card-title">Card title</h4>
                                        <p className="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                                        <a className="btn btn-primary">Button</a>
                                    </div>
                                </div>
                            </div> */}


                        {/* <div className="col-md-3" style={{ "float": "left" }}>
                                <div className="card mb-2">
                                    <img className="card-img-top"
                                        src="https://mdbootstrap.com/img/Photos/Horizontal/City/4-col/img%20(60).jpg" alt="Card image cap" />
                                    <div className="card-body">
                                        <h4 className="card-title">Card title</h4>
                                        <p className="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                                        <a className="btn btn-primary">Button</a>

                                    </div>
                                </div>
                            </div>

                            <div className="col-md-3" style={{ "float": "left" }}>
                                <div className="card mb-2">
                                    <img className="card-img-top"
                                        src="https://mdbootstrap.com/img/Photos/Horizontal/City/4-col/img%20(60).jpg" alt="Card image cap" >
                                        <div className="card-body">
                                            <h4 className="card-title">Card title</h4>
                                            <p className="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                                            <a className="btn btn-primary">Button</a>
                                        </div>
                                    </img>

                                </div>

                            </div> */}
                        {/* <!--/.First slide--> */}

                        {/* <!--Second slide--> */}
                        <div className="carousel-item">

                            <div className="col-md-3" style={{ "float": "left" }}>
                                <div className="card mb-2">
                                    <img className="card-img-top"
                                        src="https://mdbootstrap.com/img/Photos/Horizontal/City/4-col/img%20(60).jpg" alt="Card image cap">
                                        <div className="card-body">
                                            <h4 className="card-title">Card title</h4>
                                            <p className="card-text">Some quick example text to build on the card title and make up the bulk of th card's content.</p>
                                            <a className="btn btn-primary">Button</a>
                                        </div>
                                    </img>
                                </div>
                            </div>
                        </div>
                        {/* <div class="col-md-3" style="float:left">
        <div class="card mb-2">
          <img class="card-img-top"
            src="https://mdbootstrap.com/img/Photos/Horizontal/City/4-col/img%20(47).jpg" alt="Card image cap">
          <div class="card-body">
            <h4 class="card-title">Card title</h4>
            <p class="card-text">Some quick example text to build on the card title and make up the bulk of the
              card's content.</p>
            <a class="btn btn-primary">Button</a>
          </div>
        </div>
      </div>

      <div class="col-md-3" style="float:left">
        <div class="card mb-2">
          <img class="card-img-top"
            src="https://mdbootstrap.com/img/Photos/Horizontal/City/4-col/img%20(48).jpg" alt="Card image cap">
          <div class="card-body">
            <h4 class="card-title">Card title</h4>
            <p class="card-text">Some quick example text to build on the card title and make up the bulk of the
              card's content.</p>
            <a class="btn btn-primary">Button</a>
          </div>
        </div>
      </div>
      
      <div class="col-md-3" style="float:left">
        <div class="card mb-2">
          <img class="card-img-top"
            src="https://mdbootstrap.com/img/Photos/Horizontal/City/4-col/img%20(47).jpg" alt="Card image cap">
          <div class="card-body">
            <h4 class="card-title">Card title</h4>
            <p class="card-text">Some quick example text to build on the card title and make up the bulk of the
              card's content.</p>
            <a class="btn btn-primary">Button</a>
          </div>
        </div>
      </div>

    </div>
    <!--/.Second slide--> */}



                    </div>
                    {/* <!--/.Slides--> */}

                </div>
                {/* <!--/.Carousel Wrapper--> */}
                {/* </div>
            </div > */}
                {/* <Card className="box h-199 w-12 shadow p-3 mb-5 bg-white rounded ">
                <Card.Img className="box-image" src={props.book.cover} title={props.book.title} />
                <Card.Body className="box-body ">
                    <Card.Text className="h-100 w-10" >
                        <h4 style={{ "color": "black" }}><strong >Title:</strong>{props.book.title}</h4>
                        <h4><strong>Author:</strong>{props.book.author}</h4>
                        <Star value={props.book.rating}></Star>

                    </Card.Text></Card.Body>

            </Card> */}
            </div>

        </>
    )
}
export default OneCard