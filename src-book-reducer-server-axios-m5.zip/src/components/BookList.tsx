//import React, { Component } from 'react'
import { Link } from 'react-router-dom';
import React, { useContext, useEffect } from 'react'
import { book } from './book';
import OneBook from './OneBook';
import Searching from './Search';
import UserContext from './UserContext';
import { bookManager } from './bookManager'
import OneCard from './OneCard'
{/* <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"></link> */ }
interface booklistprops {
    list: book[]

}
let bmObj = new bookManager
const BookList: React.FC<booklistprops> = (props) => {
    const { booksArray, dispatch } = useContext(UserContext);
    const initialState = useContext(UserContext)

    useEffect(() => {
        bmObj.getAllBooks(dispatch);
    }, [])
    console.log("books ...")
    console.log(booksArray)
    let book = initialState.booksArray.books.map((book: any, index: any) => {
        // console.log("from booklist")
        // console.log(book.id)

        return (
            <div>
                <Link to={`/${book._id}`}>
                    <OneBook book={book}></OneBook>
                    {/* <OneCard book={book}></OneCard> */}
                </Link>
            </div>
        )

    })
    return (
        <>
            <div>
                <Searching list={props.list}></Searching>
            </div>
            <div>
                {book}
            </div>
        </>
    )
}

export default BookList

