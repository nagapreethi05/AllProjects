import axios from 'axios';
import {book} from './book'
import React, { Component } from 'react'

export class bookManager  {
    getAllBooks(dispatch:any){
        axios.get("http://localhost:9000/books")
        .then((res)=>{
            dispatch({type:"LIST",books:res.data})
        })
        .catch((err)=>{
            console.log(err.message)
        })
    }
    addBooks=async(dispatch:any,book:any,token:any)=>{
        let check=await axios.post("http://localhost:9000/books/add",book,{
            headers:{
                "Authorization":token,
                "Content-Type":"application/json"
            }
        })
        if(check.status===200){
            console.log("add")
            dispatch({type:"ADDBOOK",book:book})
        }else{
            console.log(Error);
        }
    }
    deleteBook=async(dispatch:any,id:any)=>{
        let token="Bearer "+localStorage.getItem("login");
        let check=await axios.delete("http://localhost:9000/books/"+id,{
            headers:{
                "Authorization":token,
                "Content-Type":"application/json"
            }
        })
        if(check.status===200){
            dispatch({type:"DELETE",deleteBook:id})
        }else{
            console.log(Error);
        }
    }
    render() {
        return (
            <div>
                
            </div>
        )
    }
}

export default bookManager
