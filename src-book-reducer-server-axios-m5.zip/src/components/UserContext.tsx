import React,{useReducer} from 'react'
import {book} from "./book"
import {user} from "./user"
import reducer from '../reducer'
interface Iusercontext{
    
    booksArray:{
    books:[],
    users:[],
    user:boolean,
    selectedbook:[],
   search:[]

    }
    dispatch:React.Dispatch<any>
}
const initalState={
   books:[],
   users:[
       {
           username:"preethi@gmail.com",
           password:"preethi",
           token:"1234"
       }
   ],
   user:false,
   selectedbook:[],
   search:[]
    // ,
    // users:[{
    //     "username":"preethi",
    //     "password":"preethi12",
    //     "phonenumber":"",
    //     "address":""
    // }]
}

const UserContext = React.createContext<Iusercontext>({} as Iusercontext);
const UserProvider = (props:any)=>{
    const[booksArray,dispatch]=useReducer(reducer,initalState,()=>{
        return initalState;
    })
    // console.log(booksArray)
    return(
        <UserContext.Provider value={{booksArray,dispatch}} >
            {props.children}
            </UserContext.Provider>
    )
}
const UserConsumer = UserContext.Consumer;
export {UserProvider,UserConsumer}
export default UserContext
