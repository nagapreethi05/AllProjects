 import React from 'react';
// export class Carousel {
//     render() {
//         return (
//             <>
//                 <div className="container my-4">
//                     <p>
//                         <strong>You can use slideshow component for cycling through elements—images or slides of text—like a carousel</strong>

//                     </p>

//                     <p>
//                         Detailed documentation and more examples you can find in our
//         <a
//                             href="https://mdbootstrap.com/docs/standard/components/carousel/"
//                             target="_blank"><strong>Bootstrap Carousel Docs</strong></a>
//                     </p>

//                     <hr className="mt-5"></hr>

//                     <p>Built with <a target="_blank" href="https://mdbootstrap.com/docs/standard/">Material Design for Bootstrap</a> - free and powerful Bootstrap UI KIT</p>

//                     <a className="btn btn-primary me-2" href="https://mdbootstrap.com/docs/standard/getting-started/installation/" target="_blank" role="button">Download MDB UI KIT <i class="fas fa-download"></i></a>
//                     <a className="btn btn-danger me-2" target="_blank" href="https://mdbootstrap.com/docs/standard/" role="button">Learn more</a>
//                     <a className="btn btn-success me-2" target="_blank" href="https://mdbootstrap.com/docs/standard/getting-started/" role="button">Tutorials</a>
//                     <a className="btn btn-dark me-2" target="_blank" href="https://github.com/mdbootstrap/mdb-ui-kit" role="button">GitHub <i class="fab fa-github ms-2"></i></a>

//                     <hr className="mb-5" /></div>
//                 {/* 
// <!--Carousel Wrapper--> */}
//                 <div id="multi-item-example" className="carousel slide carousel-multi-item" data-ride="carousel">

//                     {/* <!--Controls--> */}
//                     <div className="controls-top">
//                         <a className="btn-floating" href="#multi-item-example" data-slide="prev"><i className="fas fa-chevron-left"></i></a>
//                         <a className="btn-floating" href="#multi-item-example" data-slide="next"><i
//                             className="fas fa-chevron-right"></i></a>
//                     </div>
//                     {/* <!--/.Controls--> */}

//                     {/* <!--Indicators--> */}
//                     <ol className="carousel-indicators">
//                         <li data-target="#multi-item-example" data-slide-to="0" className="active"></li>
//                         <li data-target="#multi-item-example" data-slide-to="1"></li>

//                     </ol>
//                     {/* <!--/.Indicators--> */}

//                     {/* <!--Slides--> */}
//                     <div className="carousel-inner" role="listbox">
//                         </div>
//                         </div>
//                         {/* <!--First slide--> */}
//     <div className="carousel-item active">

//                             <div class="col-md-3" style="float:left">
//                                 <div className="card mb-2">
//                                     <img className="card-img-top"
//                                         src="https://mdbootstrap.com/img/Photos/Horizontal/City/4-col/img%20(60).jpg" alt="Card image cap"></img>
//                                         <div className="card-body">
//                                             <h4 className="card-title">Card title</h4>
//                                             <p className="card-text">Some quick example text to build on the card title and make up the bulk of the
//               card's content.</p>
//                                             <a className="btn btn-primary">Button</a>
//                                         </div>
//         </div>
//                                 </div>

//                                 <div className="col-md-3" style="float:left">
//                                     <div className="card mb-2">
//                                         <img className="card-img-top"
//                                             src="https://mdbootstrap.com/img/Photos/Horizontal/City/4-col/img%20(60).jpg" alt="Card image cap">
//                                             <div className="card-body">
//                                                 <h4 className="card-title">Card title</h4>
//                                                 <p className="card-text">Some quick example text to build on the card title and make up the bulk of the
//               card's content.</p>
//                                                 <a className="btn btn-primary">Button</a>
//                                             </div>

//         </div></div></div>
                                    

//                                     <div className="col-md-3" style="float:left">
//                                         <div className="card mb-2">
//                                             <img className="card-img-top"
//                                                 src="https://mdbootstrap.com/img/Photos/Horizontal/City/4-col/img%20(60).jpg" alt="Card image cap">
//                                                 <div className="card-body">
//                                                     <h4 className="card-title">Card title</h4>
//                                                     <p className="card-text">Some quick example text to build on the card title and make up the bulk of the
//               card's content.</p>
//                                                     <a className="btn btn-primary">Button</a>
//                                                 </div>
//         </div>
//                                         </div>

//                                         <div className="col-md-3" style="float:left">
//                                             <div className="card mb-2">
//                                                 <img className="card-img-top"
//                                                     src="https://mdbootstrap.com/img/Photos/Horizontal/City/4-col/img%20(60).jpg" alt="Card image cap">
//                                                     <div className="card-body">
//                                                         <h4 className="card-title">Card title</h4>
//                                                         <p className="card-text">Some quick example text to build on the card title and make up the bulk of the
//               card's content.</p>
//                                                         <a className="btn btn-primary">Button</a>
//                                                     </div>
//         </div>
//                                             </div>

//                                         </div>
//                                         <!--/.First slide-->

//     <!--Second slide-->
//     <div className="carousel-item">

//                                             <div className="col-md-3" style="float:left">
//                                                 <div className="card mb-2">
//                                                     <img className="card-img-top"
//                                                         src="https://mdbootstrap.com/img/Photos/Horizontal/City/4-col/img%20(60).jpg" alt="Card image cap">
//                                                         <div className="card-body">
//                                                             <h4 className="card-title">Card title</h4>
//                                                             <p className="card-text">Some quick example text to build on the card title and make up the bulk of the
//               card's content.</p>
//                                                             <a className="btn btn-primary">Button</a>
//                                                         </div>
//         </div>
//                                                 </div>

//                                                 <div className="col-md-3" style="float:left">
//                                                     <div className="card mb-2">
//                                                         <img className="card-img-top"
//                                                             src="https://mdbootstrap.com/img/Photos/Horizontal/City/4-col/img%20(47).jpg" alt="Card image cap">
//                                                             <div className="card-body">
//                                                                 <h4 className="card-title">Card title</h4>
//                                                                 <p className="card-text">Some quick example text to build on the card title and make up the bulk of the
//               card's content.</p>
//                                                                 <a className="btn btn-primary">Button</a>
//                                                             </div>
//         </div>
//                                                     </div>

//                                                     <div className="col-md-3" style="float:left">
//                                                         <div className="card mb-2">
//                                                             <img className="card-img-top"
//                                                                 src="https://mdbootstrap.com/img/Photos/Horizontal/City/4-col/img%20(48).jpg" alt="Card image cap">
//                                                                 <div className="card-body">
//                                                                     <h4 className="card-title">Card title</h4>
//                                                                     <p className="card-text">Some quick example text to build on the card title and make up the bulk of the
//               card's content.</p>
//                                                                     <a className="btn btn-primary">Button</a>
//                                                                 </div>
//         </div>
//                                                         </div>

//                                                         <div className="col-md-3" style={{ "float": "left" }}>
//                                                             <div className="card mb-2">
//                                                                 <img className="card-img-top"
//                                                                     src="https://mdbootstrap.com/img/Photos/Horizontal/City/4-col/img%20(47).jpg" alt="Card image cap">
//                                                                     <div className="card-body">
//                                                                         <h4 className="card-title">Card title</h4>
//                                                                         <p className="card-text">Some quick example text to build on the card title and make up the bulk of the
//               card's content.</p>
//                                                                         <a className="btn btn-primary">Button</a>
//                                                                     </div>
//         </div>
//                                                             </div>

//                                                         </div>
//                                                         {/* <!--/.Second slide--> */}



//                                                     </div>
//                                                     {/* <!--/.Slides--> */}

//                                                 </div>
//                                                 {/* <!--/.Carousel Wrapper--> */}
//                                             </div>
//             </>
//         )
//     }
// }
// export default Carousel
