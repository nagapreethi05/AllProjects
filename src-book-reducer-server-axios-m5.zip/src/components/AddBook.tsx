import react, { useState, useContext } from 'react';
import { book } from './book'
import Reducer from '../reducer'
import { useHistory } from 'react-router-dom'
import UserContext from './UserContext'
import bookManager from './bookManager'
// import { dispatch, action } from "../reducer"

// const {booksArray,dispatch}=useContext(UserContext)
const AddBook = (props: any) => {
    const { dispatch } = useContext(UserContext)
    const [title, setTitle] = useState("");
    const [author, setAuthor] = useState("");
    const [rating, setRating] = useState(0);
    const [price, setPrice] = useState(0);
    const [cover, setCover] = useState("");
    const [body, setDescription] = useState("");
    const bookManagerObj = new bookManager
    const history = useHistory();
    const inputtitle = (e: any) => {
        setTitle(e.target.value)
    }
    const inputauthor = (e: any) => {
        setAuthor(e.target.value)
    }
    const inputrating = (e: any) => {
        setRating(e.target.value)
    }
    const inputprice = (e: any) => {
        setPrice(e.target.value)
    }
    const inputcover = (e: any) => {
        setCover(e.target.value)
    }
    const inputdescription = (e: any) => {
        setDescription(e.target.value)
    }
    const handleSubmit = () => {
        const book = {
            cover: cover,
            title: title,
            price: price,
            rating: rating,
            author: author,
            body: body
        }
        let token = "Bearer " + localStorage.getItem("login");
        bookManagerObj.addBooks(dispatch, book, token)
    }
    return (
        <div>
            {/* <span>
                <form><br></br>
                    <label className="llabel" >Enter Title</label><input type="text" className="iinput" required onChange={inputtitle}></input><br /><br />
                    <label className="llabel" >Enter Author</label><input type="text" className="iinput" required onChange={inputauthor}></input><br /><br />
                    <label className="llabel" >Enter Rating</label><input type="text" className="iinput" required onChange={inputrating}></input><br /><br />
                    <label className="llabel" >Enter Price</label><input type="text" className="iinput" required onChange={inputprice}></input><br /><br />
                    <label className="llabel" >Enter Cover</label><input type="text" className="iinput" required onChange={inputcover}></input><br /><br />
                    <label className="llabel" >Enter Description</label><textarea className="iinput" required onChange={inputdescription}></textarea><br /><br />
                    <button className="bbutton" type="button" onClick={() => { handleSubmit() ;history.push("/")}}>submit</button>
                </form>
            </span> */}
            <div className="container shadow p-3 mb-9 bg-white rounded">
                <h1>Add Book</h1>
                <p>Please fill in the Details of your book</p>
                <hr></hr>
                <form>
                    <label ><b>Enter Title</b></label>
                    <input type="text" placeholder="Enter Title" name="email" id="email" required onChange={inputtitle} />
                    <label ><b>Author</b></label>
                    <input type="text" placeholder="EnterAuthor" name="psw" id="psw" required onChange={inputauthor} />
                    <label ><b>Enter Rating</b></label>
                    <input type="text" placeholder="Enter Rating" name="email" id="email" required onChange={inputrating} />
                    <label ><b>Enter Price</b></label>
                    <input type="text" placeholder="Enter Price" name="email" id="email" required onChange={inputprice} />
                    <label ><b>Enter Cover</b></label>
                    <input type="text" placeholder="Enter Cover" name="email" id="email" required onChange={inputcover} />
                    <label ><b>Enter Description</b></label>
                    <input type="text" placeholder="Enter Description" name="email" id="email" required onChange={inputdescription} />
                    <hr></hr>
                    <button type="submit" className="registerbtn" onClick={() => { handleSubmit(); history.push("/") }}>Add Book</button>
                </form>
            </div>
        </div>
    )
}
export default AddBook;
