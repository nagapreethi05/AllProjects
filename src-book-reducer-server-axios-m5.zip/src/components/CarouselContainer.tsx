import React from 'react';
import { Carousel } from 'react-bootstrap';
import BookList from '../components/BookList'
import image1 from '../images/04.jpg';
import image4 from '../images/004.jpg';
import image3 from '../images/003.jpg';
import image2 from '../images/020.jpg';
const CarouselContainer = () => {
  return (
    <Carousel fade={true} pause={false}>
      <Carousel.Item interval={3000}>
        <img
          className="d-block w-100 img"
          src={image1}
          alt="First slide"
        />
        {/* <BookList list={books}></BookList> */}
        {/* <OneBook book={book}></OneBook> */}
        <Carousel.Caption>
          <h3 style={{"backgroundColor":"grey","fontFamily":"cursive"}}>If you only read the books that everyone else is reading, you can only think what everyone else is thinking.</h3>

        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item interval={3000}>
        <img
          className="d-block w-100 img"
          src={image2}
          alt="Third slide"
        />
        <Carousel.Caption>
          <h3 style={{"backgroundColor":"grey","fontFamily":"cursive"}}>
          You can’t buy happiness, but you can buy books and that’s kind of the same thing.</h3>
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item interval={3000}>
        <img
          // style={{"height": "500px" }}
          className="d-block w-100 img"
          src={image3}
          alt="Third slide"
        />
        <Carousel.Caption>
          <h3 style={{"backgroundColor":"grey","fontFamily":"cursive"}}>Always read something that will make you look good if you die in the middle of it.</h3>
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item interval={3000}>
        <img
          className="d-block w-100 img"
          src={image4}
          alt="Fourth slide"
        />
        <Carousel.Caption>
          <h3 style={{"backgroundColor":"grey","fontFamily":"cursive"}}>
          A good novel tells us the truth about its hero; but a bad novel tells us the truth about its author.</h3>
        </Carousel.Caption>
      </Carousel.Item>
    </Carousel>

  )
}

export default CarouselContainer;