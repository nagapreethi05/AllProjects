import React, { useContext, useState } from 'react';
import UserContext from './UserContext'
import { Button, Col, Form } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css'
interface Iprops {
  handlelogin: (loginUser: any) => void

}


const Login = (Iprops: any) => {
  const [username, setUserName] = useState("");
  const [password, setPassword] = useState("");
  const{dispatch}=useContext(UserContext)
  function inputlusername(e: any) {
    setUserName(e.target.value)
  }
  function inputlpassword(e: any) {
    setPassword(e.target.value)
  }


  return (<>
    {/* <div className="login"><h3>Login</h3>

            <p>Enter UserName:<input type="text"></input><br /><br />
        Enter Password:<input type="text"></input><br /><br /></p> */}
    {/* <Form>
      <Form.Group as={Col} controlId="formGridEmail">
        <Form.Label>User Name </Form.Label>
        <Form.Control type="email" placeholder="Enter email" onChange={inputlusername} />
      </Form.Group>
      <Form.Group as={Col} controlId="formGridPassword" >
        <Form.Label>Password</Form.Label>
        <Form.Control type="password" placeholder="Password" onChange={inputlpassword} /><br />
      </Form.Group>
    </Form>
    <Button variant="success" type="button" onClick={() => Iprops.handlelogin({ username: username, password: password })}>Login</Button>
    {Iprops.valid === "error" ? <div style={{ color: "red" }}>invalid username or password</div> : null} */}

    {/* </div> */}
    <br/>
    <div className="container shadow p-3 mb-9 bg-white rounded " >
    <h1>Login</h1>
    <p>Please fill in this form to login</p>
    <hr></hr>

    <label ><b>User Name</b></label>
    <input type="text" placeholder="Enter Email" name="email" id="email" required onChange={inputlusername}/>

    <label ><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="psw" id="psw" required onChange={inputlpassword}/>
    {Iprops.valid === "error" ? <div style={{ color: "red" }}>invalid username or password</div> : null}
    <hr></hr>
    

    <button type="submit" className="registerbtn" onClick={() => {Iprops.handlelogin({ username: username, password: password });dispatch({type:"LOGIN"});}}>Login</button>
  </div>
  
  
  </>

  )
}
export default Login
