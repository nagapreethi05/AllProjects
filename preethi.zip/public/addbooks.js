"use strict";
// function addbook(){
//     let newid=document.getElementById("newid").value;
//     let newtitle=document.getElementById("newtitle").value;
//     let newauthor=document.getElementById("newauthor").value;
//     let newprice=document.getElementById("newprice").value;
//     let newrating=document.getElementById("newrating").value;
// }
